import { View, StyleSheet } from "react-native";
import Input from "./Input";
import { useState } from "react";
import Button from "../../UI/Button";

export default function NotesForm({submitButtonLabel, onCancel, onSubmit}) {
  const [content, setContent] = useState("");
  function contentChangeHandler(enteredContent) {
    setContent(enteredContent);
  }

  function editNoteContent() {
    onSubmit(content);
  }
  return (
    <View>
      <Input
        label="Content"
        textInputConfig={{
          onChangeText: contentChangeHandler,
          value: content,
        }}
      />
      <View style ={styles.buttons}>
        <Button style = {styles.cancelbutton} mode="flat" onPress={onCancel}>
          Cancel
        </Button>
        <Button style = {styles.button} onPress={editNoteContent}>{submitButtonLabel}</Button>
      </View>
    </View>
  );
}


const styles = StyleSheet.create({
  buttons:{
    flexDirection: 'row',
    justifyContent: 'center',
    alignItems: 'center',
  },
  button:{
    minWidth:120,
    marginHorizontal: 8
  },
})