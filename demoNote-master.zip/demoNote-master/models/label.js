class Label {
    constructor(id, label) {
        this.id = id;
        this.label = label;
    }
}

export default Label;