import React, { useContext, useLayoutEffect } from "react";
import { Text, View, StyleSheet } from "react-native";
import NoteItem from "../components/NotesOutput/NoteItem";
import { NotesContext } from "../components/context/NotesContext";
import { GlobalStyles } from "../constants/colors";
import IconButton from "../UI/IconButton";
import Button from "../UI/Button";
import NotesForm from "../components/manageNotes/NotesForm";

function EditNoteScreen({ route, navigation }) {
  const NoteCtx = useContext(NotesContext);
  const editedNoteID = route.params.noteId;
  const isEditing = !!editedNoteID;
  useLayoutEffect(() => {
    navigation.setOptions({
      Title: isEditing ? "Edit Note" : "Add Note",
    });
  }, [navigation, isEditing]);

  function deleteNoteHandler() {
    NoteCtx.deleteNote(editedNoteID);
    navigation.goBack();
  }
  function cancelNoteHandler() {
    navigation.goBack();
  }
  function editNoteHandler(NoteData) {
    NoteCtx.editNote(editedNoteID, NoteData);
    alert('Note updated successfully!');
    navigation.goBack();
  }
  return (
    <View style={styles.container}>
        <NotesForm submitButtonLabel={isEditing ? 'Update':'Add'} onCancel = {cancelNoteHandler} onSubmit = {editNoteHandler}/>
      {isEditing && (
        <View style={styles.deleteContainer}>
          <IconButton
            icon="trash"
            color={GlobalStyles.colors.error500}
            size={50}
            onPress={deleteNoteHandler}
          />
        </View>
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 24,
  },
  deleteContainer: {
    marginTop: 16,
    paddingTop: 8,
    borderTopWidth: 2,
    borderTopColor: GlobalStyles.colors.primary200,
    alignItems: "center",
    paddingLeft:"30%"
  },
  cancelbutton:{
    minWidth:120,
    marginHorizontal: 8,
    backgroundColor: 'yellow',
  },
});

export default EditNoteScreen;
