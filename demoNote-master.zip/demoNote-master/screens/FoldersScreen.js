import { Text } from "react-native";

function FoldersScreen() {
    return ( <Text>Folders</Text> );
}

export default FoldersScreen;