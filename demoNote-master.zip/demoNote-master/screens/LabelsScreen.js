import { Text } from "react-native";

function LabelsScreen() {
    return ( <Text>Labels</Text> );
}

export default LabelsScreen;