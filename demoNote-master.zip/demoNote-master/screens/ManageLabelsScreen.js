import { Text } from "react-native";

function ManageLabelsScreen() {
    return ( <Text>ManagedLabels</Text> );
}

export default ManageLabelsScreen;