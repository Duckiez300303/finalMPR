import { Text } from "react-native";

function TrashScreen() {
    return ( <Text>Trash</Text> );
}

export default TrashScreen;